# Upgrade Progress

  ### ⏳ Generate Upgrade Plan ...Running [View Log](logs/1.generatePlan.log)
  
  - ###
    ### ⏳ Install JDK 11 ...Running